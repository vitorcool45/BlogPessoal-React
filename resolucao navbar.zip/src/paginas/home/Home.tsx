import React from "react";
import './Home.css';
import {Button, Box, Paper} from '@material-ui/core';
   
function Home(){
    return(
        <>
          <h1>Home</h1>
            </>
    );
}  

export default Home;
